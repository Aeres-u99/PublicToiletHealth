test = 1234
primary_Gasbuffer = ['Error0xA:No IOt device found!']
primary_LDRbuffer = ['Error0xA:No IOT device found!']
secondary_Gasbuffer = ['Error0xB']
secondary_LDRbuffer = ['Error0xB']

